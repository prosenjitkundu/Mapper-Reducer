from operator import itemgetter
import sys

dict = {}
dict_cnt = {}
emp1 = None
emp2 = None
depid1 = None
depid2 = None
dict_max = {"mx":-1}

# input comes from STDIN
for line in sys.stdin:
    # remove leading and trailing whitespace
    line = line.strip()
    # parse the input we got from mapper.py
    emp1, emp2, depid1, depid2, countr = line.split('\t')
    #Iterate through the loop if the depid1 are depid2 different
    if(depid1 != depid2):

        # convert count (currently a string) to int
        try:
            countr = int(countr)

        except ValueError:
            continue

        emp = emp1 +" "+ emp2
        if depid1 in dict:
            if emp not in dict[depid1]:
                dict[depid1].append(emp)
                #incrementing outgoing mail count
                dict_cnt[depid1] += countr 
        else:
            dict[depid1] = []
            dict[depid1].append(emp)
            #initialize the initial count to 1
            dict_cnt[depid1] = countr

for keyM in dict_cnt:
    pres_max = min(dict_max, key = lambda k:dict_max[k])
    #Looking for department with maximum outgoing mail 
    if dict_cnt[keyM] > dict_max[pres_max]:
        del dict_max[pres_max]
        dict_max[keyM] = dict_cnt[keyM]
# print department with maximum outgoing mail count
for keyn in dict_max:
    print('%s\t%s'%(keyn, str(dict_max[keyn])))