import sys

#List to store the employee and its respective department
empidx = []
deptidx = []
fp = open("dept_labels.txt")
Lines = fp.readlines()

for ln in Lines:
    empid, depid = ln.split(' ')

    empidx.append(empid)
    deptidx.append(depid.replace("\n",""))
    #query[empid] = depid.replace("\n","") #replace '\n' with ''
    #print(depid)

for line in sys.stdin:
    #stripping extra spaces
    line = line.strip()

    #splitting each line on ' ' deliminator
    #store employee1 in emp1 and employee2 in emp2
    emp1, emp2 = line.split(' ')
    #printing emp1 and emp2 with their respective department

    emp = emp1 + '\t' + emp2 + '\t' + deptidx[empidx.index(emp1)] + '\t' +  deptidx[empidx.index(emp2)]
    print('%s\t%s'%(emp,1))
    