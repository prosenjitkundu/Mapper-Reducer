from operator import itemgetter
import sys

dict = {}
dict_cnt = {}
emp1 = None
emp2 = None

# input comes from STDIN
for line in sys.stdin:
    # remove leading and trailing whitespace
    line = line.strip()
    # parse the input we got from mapper.py

    emp1, emp2, countr = line.split('\t')

    # convert count (currently a string) to int
    try:
        countr = int(countr)

    except ValueError:
        continue

    if emp1 in dict:
        if emp2 not in dict[emp1]:
            dict[emp1].append(emp2)
            dict_cnt[emp1] += countr  #incrementing word count
    else:
        dict[emp1] = []
        dict[emp1].append(emp2)
        dict_cnt[emp1] = countr

for key in dict:
    print('%s\t%s'%(key,str(dict_cnt[key])))
    