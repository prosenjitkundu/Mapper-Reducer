import sys
from operator import itemgetter

word = -1

#Storiing the top 10 employee
temp_dict = {"a":-1, "b":-1, "c":-1, "d":-1, "e":-1, 
				"f":-1, "g":-1, "h":-1, "i":-1, "j":-1}

# input comes from STDIN
for line in sys.stdin:
    # remove leading and trailing whitespace
    line = line.strip()
    # parse the input we got from mapper.py
    user1, sendemp, countr = line.split('\t')

    # convert count (currently a string) to int
    try:
        word = int(sendemp)

    except ValueError:
        continue
    #finding the minimum value in the dictionary 
    val_data = min(temp_dict, key = lambda k:temp_dict[k])
    # replace with the maximum value
    if word > temp_dict[val_data]:
        del temp_dict[val_data]
        temp_dict[user1] = word


#print(temp_dict)
#print the top 10 employee with respect to their send mail count(maximum)
idx = 1
for nd in temp_dict:
    if idx < 10:
        print('%s\t%s' %(nd, temp_dict[nd]))
    else:
        print('%s\t%s' %(nd, temp_dict[nd]), end ='')
    idx+=1
