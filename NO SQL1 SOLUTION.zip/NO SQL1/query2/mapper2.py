import sys

for line in sys.stdin:
    #stripping extra spaces
    line = line.strip()

    #splitting each line on '\t' deliminator
    words=line.split('\t')

    #store employee1 in user1 and employee2 in user2
    user1=words[0]
    user2=words[1]

    emp = user1 + '\t' + user2

    #printing each employee we get
    print('%s\t%s'%(emp,1))