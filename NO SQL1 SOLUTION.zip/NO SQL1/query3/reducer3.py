import sys
from operator import itemgetter

dict = {}
dict_cnt = {}
emp1 = None
topr = None

# input comes from STDIN
for line in sys.stdin:
    # remove leading and trailing whitespace
    line = line.strip()
    # parse the input we got from mapper.py
    emp1, topr, countr = line.split('\t')

    # convert count (currently a string) to int
    try:
        countr = int(countr)

    except ValueError:
        continue

    if topr in dict:
        if emp1 not in dict[topr]: 
            dict[topr].append(emp1)
            #incrementing mail to topper count
            dict_cnt[topr] += countr 
    else:
        dict[topr] = []
        dict[topr].append(emp1)
        #initialize the initial count to 1
        dict_cnt[topr] = countr

for key in dict:
    print('%s\t%s'%(key,str(dict_cnt[key])))