
import sys

#list to store the top 10 result of the previous query 
top10 = []
fp = open("result2.txt")
Lines = fp.readlines()
#storing the top users in a list 
for ln in Lines:
    tmp = ln.split('\t')
    top10.append(tmp[0])
#print(top10)


for line in sys.stdin:
    #stripping extra spaces
    line = line.strip()

    #splitting each line on ' ' deliminator
    words=line.split(' ')

    #store employee1 in user1 and employee2 in user2
    user1=words[0]
    user2=words[1]
    #printing the employee who have send to the top 10 users
    if(user2 in top10):
        emp = user1+ '\t' + user2
        print('%s\t%s'%(emp,1))
